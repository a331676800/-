(function(){
    var itemTmpl = '<div class="order-item">'+
                        '<div class="order-inner">'+
                            '<img class="order-img" src="$url">'+
                            '<div class="order-right">'+
                                '<div class="order-top">'+
                                    '<div class="order-name one-line">$name</div>'+
                                    '<div class="arrow"></div>'+
                                    '<div class="order-state">$status</div>'+
                                '</div>'+
                                '<div class="order-mid">$mid</div>'+                           
                            '</div>'+
                        '</div>'+
                        '$pingjia'+
                    '</div>';
    var isLoading = false;
    var page = 0;


    function pingjia(data){
        var comment = !data.is_comment;
        if(comment){
            return '<div class="pj-container clearfix">'+
                        '<div class="pj-img">评价</div>'+
                    '</div>';
        }else{
            return '<div class="pj-container"></div>';
        }
    }
    function midbottom(data){
        var str = '<div class="mid-item">...'+
                        '<div class="mid-all">总计'+data.product_count+'个菜，实付'+
                            '<span>￥'+data.total+'</span>'+
                        '</div>'+
                    '</div>';
        return str;
    }
    function setMid(data){
        var list = data.product_list || [];
        list.push({type:'more'});
        var str = '';
        list.forEach(function(item,index){
            if(item.type==='more'){
                str += midbottom(data);
            }else{
                str += '<div class="mid-item">'+
                            '<div class="mid-name">'+item.product_name+'</div>'+
                            '<div class="mid-many">x'+item.product_count+'</div>'+
                       '</div>';
            }
        })
        return str;
    }
    function initList(data){
        data.forEach(function(item,index){
            var str = itemTmpl.replace('$url',item.poi_pic)
                              .replace('$name',item.poi_name)
                              .replace('$status',item.status_description)
                              .replace('$mid',setMid(item))
                              .replace('$pingjia',pingjia(item))
            $('.order-container').append(str);
        })
    }
    function getData(){
        page++;
        isLoading = true;
        $.get('..\\json\\orders.json',function(data){
            console.log(data);
            var list = data.data.digestlist || [];
            initList(list);
            isLoading = false;
        })
        
    }

    function addEven(){
        window.addEventListener('scroll',function(){
            var clientHeight = document.documentElement.clientHeight;
            var scrollTop = document.documentElement.scrollTop || document.body.scrollTop;
            var scrollHeight = document.body.scrollHeight;
            var yuzhi = 30;
            if((scrollTop + clientHeight) >= (scrollHeight - yuzhi)){
                if(page < 3){
                    if(isLoading){
                        return;
                    }else{
                        getData();
                    }
                }else{
                    $('.load').text('加载完成');
                }
            }
            
        })
    }
    function init(){
        getData();
        addEven()
    }
    init();
})()