(function(){

    var itemTmpl = '<a class="tab-item $key" href="../$key/$key.html">'+
                        '$text'+
                    '</a>';


    function init(){
        var items = [{
            key:'menu',
            text:'点菜'
        },{
            key:'comment',
            text:'评价'
        },{
            key:'restanurant',
            text:'商家'
        }]
        var str = '';
        items.forEach(function (item){
        str += itemTmpl.replace(/\$key/g,item.key)
                            .replace('$text',item.text)
    })
        $('.tabBar').append(str);
        active();
    }
    
    function active(){
        var path = window.location.pathname;
        var path2 = path.split('/');
        var page = path2[path2.length-1].replace('.html','');
        console.log(page)

    $('a.'+page).addClass('active');
    }
    
    init();

})()