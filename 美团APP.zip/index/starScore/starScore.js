(function(){

    var itemTmpl = '<div class="star-score">$star-score</div>';

    function _setStar(){
        var _score = this.score.toString();
        var starArray = _score.split('.');
        //满星
        var fullStar = parseInt(starArray[0]);
        //半星
        var halfStar = parseInt(starArray[1]) >= 5? 1:0;
        //没星
        var nullStar = 5 - fullStar - halfStar;
        //定义变量用于存储dom内容
        var strStar = '';

        for(var i=0;i<fullStar;i++){
            strStar += '<div class="star fullstar"></div>';
        }
        for(var j=0;j<halfStar;j++){
            strStar += '<div class="star halfstar"></div>';
        }
        for(var k=0;k<nullStar;k++){
            strStar += '<div class="star nullstar"></div>';
        } 
        return itemTmpl.replace('$star-score',strStar);
    }
    window.StarScore = function(score){
        this.score = score || '';
        this.setStar = _setStar;
    }



    // var itemTmpl = '<div class="star-score">$star</div>';


    // function _setStar(){
    //     var _score = this.score.toString();
    //     var arr = _score.split('.');
    //     var fullStar = parseInt(arr[0]);
    //     var halfStar = parseInt(arr[1]) >= 5?1:0;
    //     var nullStar = 5-fullStar-halfStar;
    //     var starStr = '';

    //     for(var i=0;i<fullStar;i++){
    //         starStr += '<div class="star fullstar"></div>';
    //     }
    //     for(var j=0;j<halfStar;j++){
    //         starStr += '<div class="star halfstar"></div>';
    //     }
    //     for(var k=0;k<nullStar;k++){
    //         starStr += '<div class="star nullstar"></div>';
    //     }
    //     return itemTmpl.replace('$star',starStr);
    // }

    // window.StarScore = function(score){
    //     this.score = score || [];
    //     this.setStar = _setStar;
    // }

























})()