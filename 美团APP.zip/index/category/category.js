(function(){
    var itemTmpl = '<div class="category-item">' +
                        '<img class="item-icon" src="$url"/>' +
                        '<p class="category-name">$name</p>'+
                   '</div>';
        function initCategory(){
            $.get('json\\head.json',function(data){
                console.log(data);
                var list = data.data.primary_filter.splice(0,8);
                list.forEach(function(item,index){
                    var str = itemTmpl
                    .replace('$url',item.url)
                    .replace('$name',item.name);
                    $('.category').append(str);
                })
            })
        }

        function categoryClick(){
            $('.category').on('click','.category-item',function(){
                alert(1);
            })
        }
        function init(){
            initCategory();
            categoryClick();
        }
        init();
})()


