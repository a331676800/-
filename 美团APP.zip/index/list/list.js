(function(){
    var itemTmpl = '<div class="list-content">'+
                        '<div class="list-left">'+
                            '<img src="$url" class="list-img" />'+
                            '$brand'+
                        '</div>'+
                        '<div class="list-right">'+
                            '<div class="list-r-name">$name</div>'+
                            '<div class="list-two clearfix">'+
                                '<div class="score">$score</div>'+
                                '<div class="many">月售$namy</div>'+
                                
                                '<div class="km">&nbsp;$km</div>'+
                                '<div class="time">$time&nbsp;|</div>'+
                            '</div>'+
                            '<div class="price">$price</div>'+
                            '<div class="item-order">'+
                            '$order'+
                            '</div>'+
                        '</div>'+
                    '</div>';


    var isLoading = false;
    var page = 0;
    function initJson(){
        page++;
        isLoading = true;
        $.get('json\\homelist.json',function(data){
            console.log(data);
            var list = data.data.poilist || [];
            setDom(list);
            isLoading = false;
        })
        
        console.log(1);
    }
    function monthSaleNum(list){
        if(list.month_sale_num>999){
            return '999+';
        }else{
            return list.month_sale_num;
        }
    }
    function setBrand(list){
        if(list.brand_type){
            return '<div class="brand pin">品牌</div>';
        }else{
            return '<div class="brand xin">新品</div>';
        }
    }
    function setOrder(list){
        var array = list.discounts2;
        var str = '';
        array.forEach(function(item,index){
            var _str =  '<div class="order">'+
                            '<img class="order-img" src="$url-icon">'+
                            '<p class="order-text one-line">$order-text</p>'+
                        '</div>';
            _str = _str.replace('$url-icon',item.icon_url)
                       .replace('$order-text',item.info);
            str = str + _str;
        })
        return str;
    }
    function setDom(list){
        list.forEach(function(item,index){
            var str = itemTmpl
                      .replace('$url',item.pic_url)
                      .replace('$name',item.name)
                      .replace('$brand',setBrand(item))
                      .replace('$namy',monthSaleNum(item))
                      .replace('$time',item.mt_delivery_time)
                      .replace('$km',item.distance)
                      .replace('$price',item.min_price_tip)
                      .replace('$order',setOrder(item))
                      .replace('$score',new StarScore(item.wm_poi_score).setStar());
            $('.list-item').append(str);
        })
        
    }


    function addEven(){
        window.addEventListener('scroll',function(){
            var clientHeight = document.documentElement.clientHeight;
            var scrollTop = document.documentElement.scrollTop || document.body.scrollTop;
            var scrollHeight = document.body.scrollHeight;
            var bl = 30;
            if((scrollTop+clientHeight) >= (scrollHeight-bl)){
                if(page < 3){
                    if(isLoading){
                        return;
                    }else{
                        initJson();
                    }
                }else{
                    $('.load').text('加载完成');
                }
            }
        })
    }
    function init(){
        initJson();
        addEven();
    }

    init();
})()