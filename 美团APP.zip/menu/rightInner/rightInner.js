(function(){

    var itemTmpl = '<div class="right-item">'+
                        '<img src="$url" class="right-img">'+       
                        '<div class="item-content">'+
                            '<p class="content-name">$name</p>'+
                            '<p class="content-mid">$mid</p>'+
                            '<p class="content-zan">$zan</p>'+
                            '<p class="content-price">￥$min_price<span class="unit">/$unit</span></p>'+
                        '</div>'+
                        '<div class="select">'+
                            '<div class="minus"></div>'+
                            '<div class="count">$chooseCount</div>'+
                            '<div class="plus"></div>'+
                        '</div>'+
                    '</div>';

    function initRightList(list){
        $('.right-bar-inner').html('');
        list.forEach(function(item,index){ 
            if(!item.chooseCount) {
                item.chooseCount = 0;
            }
            var str = itemTmpl.replace('$url',item.picture)
                                .replace('$name',item.name)
                                .replace('$mid',item.description)
                                .replace('$zan',item.praise_content)
                                .replace('$min_price',item.min_price)
                                .replace('$unit',item.unit)
                                .replace('$chooseCount',item.chooseCount);
            var $target = $(str);
            $target.data('itemData',item);
            $('.right-bar-inner').append($target);
        })
    }
    function initRightTitle(str){
        $('.right-title').text(str);
    }
    function init(data){
        initRightList(data.spus || []);
        initRightTitle(data.name);
        addClick();
    }


    function addClick(){
        $('.right-item').on('click','.plus',function(e){
            var $count = $(e.currentTarget).parent().find('.count');
            $count.text(parseInt($count.text()||'0')+1);
            var $items = $(e.currentTarget).parents('.right-item').first();
            var itemData = $items.data('itemData');
            itemData.chooseCount += 1;
            window.ShopBar.renderItems();
        })
        $('.right-item').on('click','.minus',function(e){
            var $count = $(e.currentTarget).parent().find('.count');
            if($count.text() == 0) return;
            $count.text(parseInt($count.text()||'0')-1);
            var $items = $(e.currentTarget).parents('.right-item').first();
            var itemData = $items.data('itemData');
            itemData.chooseCount -= 1;
            window.ShopBar.renderItems();
        })
    }

    function clear(itemData){
        var $items = $('shopbar').find('.right-item');
        for(var i=0;i<$items.length;i++){
            var $item = $items[i];
            var itemData = $item.data('itemData');
            itemData.chooseCount = 0;
        }
        initRightList(itemData);
        $('.left-item').first().click();
    }
    window.Right = {
        refresh:init,
        clear:clear
    }



})()