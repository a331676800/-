(function(){

    var itemTmpl = '<div class="left-item">'+
                        '<div class="item-inner">$content</div>'+
                    '</div>';

    function getData(){
        $.get('..\\json\\food.json',function(data){
            console.log(data);
            window.food_spu_tags = data.data.food_spu_tags || [];
            initContent(window.food_spu_tags);
            console.log(window.food_spu_tags);
            window.ShopBar.changeShippingPrice(data.data.poi_info.shipping_fee)
        })
    }
    function initContent(list){
        list.forEach(function(item,index){
            var str = itemTmpl.replace('$content',icon(item));
            var $target = $(str);
            $target.data('itemData',item);
            $('.left-bar-inner').append($target);
            // console.log($target)
        })
        $('.left-item').first().click();
    }
    function icon(list){
        if(list.icon){
            return '<img src='+list.icon+' />'+list.name;
        }else{
            return list.name;
        }
    }
    function addClick(){
        $('.menu-inner').on('click','.left-item',function(e){
            // console.log($(e.currentTarget));
            var $target = $(e.currentTarget);
            // console.log($target.data('itemData'));
            $target.addClass('active');
            $target.siblings().removeClass('active');
            window.Right.refresh($target.data('itemData'));
            
        })
    }
    // function initContent(list) {


    //     list.forEach(function(item, index){


    //         var str = itemTmpl

    //         .replace('$content',icon(item))

    //         var $target = $(str);
    //         $target.data('itemData',item);

    //         $('.left-bar-inner').append($target);

    //     });


    //     $('.left-item').first().click();


    // }



    // function addClick(){
    //     $('.menu-inner').on('click','.left-item', function(e){

    //         var $target = $(e.currentTarget);
    //         $target.addClass('active');
    //         $target.siblings().removeClass('active');
    //         Right.refresh($target.data('itemData'));
    //     });
    // }
    function init(){
        getData();
        addClick();
    }
    init();

})()