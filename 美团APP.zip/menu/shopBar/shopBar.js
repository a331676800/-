(function(){

    var itemTopTmpl = '<div class="choose-content hide">'+
                            '<div class="content-top">'+
                                '<div class="clear-car">清空购物车</div>'+
                            '</div>'+
                        '</div>';
    var itemBottomTmpl = '<div class="shopBar-bottom">'+
                                '<div class="icon">'+
                                    '<div class="dot hide"></div>'+
                                '</div>'+
                                '<div class="shopBar-right">'+
                                    '<div class="price-all">'+
                                        '<div class="price-top">￥<span class="total">0</span></div>'+
                                        '<div class="other-price">另需配送&nbsp;￥<span class="shipping">0</span></div>'+
                                    '</div>'+
                                    '<div class="price-btn">去结算</div>'+
                                '</div>'+
                        '</div>';


    var $topItem = $(itemTopTmpl),
        $bottomItem = $(itemBottomTmpl);
    function renderItems(){
        $topItem.find('.shopBar-item').remove();
        var list = window.food_spu_tags || [];
        var str = '<div class="shopBar-item">'+
                        '<div class="item-name">$name</div>'+
                        '<div class="item-price">￥<span>$price</span></div>'+
                        '<div class="select">'+
                            '<div class="minus"></div>'+
                            '<div class="count">$chooseCount</div>'+
                            '<div class="plus"></div>'+
                        '</div>'+
                    '</div>';
        
        var totalPrice = 0;  //总价
        //进行两次遍历到spus
        list.forEach(function(item){
            item.spus.forEach(function(_item){
                if(_item.chooseCount > 0){
                    //每一件商品的总价
                    var price = _item.min_price*_item.chooseCount;
                    //替换掉替代字符
                    var row = str.replace('$name',_item.name)
                            .replace('$price',price)
                            .replace('$chooseCount',_item.chooseCount);
                    //总价等于所有商品的价格相加
                    totalPrice += price;
                    //数据挂载到$row上面
                    $row = $(row);
                    $row.data('itemData',_item);
                    //将$row放入$topItem里
                    $topItem.append($row);
                }
                
            })
        })
        changeTotalPrice(totalPrice);
        dotShowHide();
    }
    function changeShippingPrice(str){
        $bottomItem.find('.shipping').text(str);
    }
    function changeTotalPrice(str){
        $bottomItem.find('.total').text(str);
    }
    function dotShowHide(){
        var $counts = $topItem.find('.count');
        var total = 0;
        for(var i = 0;i < $counts.length;i++){
            total += parseInt($($counts[i]).text());
        }
        if(total > 0){
            $('.dot').show();
            $('.dot').text(total);
        }else{
            $('.dot').hide();
        }
        
    }
    function addClick(){  //为什么$topItem换成$('.shopBar-item')就不生效了
        $topItem.on('click','.plus',function(e){
            var $count = $(e.currentTarget).parent().find('.count');
            $count.text(parseInt($count.text() || '0' + 1));
            var $items = $(e.currentTarget).parents('.shopBar-item').first();
            var itemData = $items.data('itemData');
            console.log($count)
            itemData.chooseCount += 1;
            renderItems();
            $('.left-item.active').click(); //这个为什么能实现交互，不懂..
        })
        $topItem.on('click','.minus',function(e){
            var $count = $(e.currentTarget).parent().find('.count');
            if($count.text() == 0) return;
            $count.text(parseInt($count.text() || '0' - 1));
                var $items = $(e.currentTarget).parents('.shopBar-item').first();
                var itemData = $items.data('itemData');
                itemData.chooseCount -= 1;  
                renderItems();
                $('.left-item.active').click(); 
        })
        $('.shopbar').on('click','.icon',function(){
            $('.mask').toggle();
            $('.choose-content').toggle();
        })

        //点击mask区域隐藏mask和choosecontent区域
        $('.mask').on('click',function(){
            $('.choose-content').toggle();
            $('.mask').toggle();
        })
        $topItem.on('click','.clear-car',function(e){
            const $items = $topItem.find('.shopBar-item');
            $('.dot').text('0').hide();
            
            for (let i = 0; i < $items.length; i++) {
                var item = $items[i];
                var itemData = $(item).data('itemData');
                // console.log(itemData);
                itemData.chooseCount = 0;
            }
            renderItems();
            $items.remove();
            window.Right.clear(window.food_spu_tags.spus || []);
        })
        
    }
    function init(){
        $('.shopbar').append($topItem);
        $('.shopbar').append($bottomItem);
        addClick();
    }
    init();
    window.ShopBar = {
        renderItems:renderItems,
        changeShippingPrice:changeShippingPrice
    }

})()